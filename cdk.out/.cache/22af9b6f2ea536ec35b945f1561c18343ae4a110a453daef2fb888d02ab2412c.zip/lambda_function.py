def lambda_handler(event, context):
    # Your Lambda code here
    return {
        'statusCode': 200,
        'body': 'Hello from Lambda!'
    }